document.getElementById('contact-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value,
    company: form.company.value,
    email: form.email.value,
    project: form.project.value
  };

  document.getElementById('status').innerText = '⏳ Sending...';

  try {
    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      document.getElementById('status').innerText = '✅ Your message has been sent successfully!';
      form.reset();
    } else {
      document.getElementById('status').innerText = '❌ Error sending message. Please try again.';
    }
  } catch (err) {
    document.getElementById('status').innerText = '❌ Network error. Please try again later.';
  }
});
